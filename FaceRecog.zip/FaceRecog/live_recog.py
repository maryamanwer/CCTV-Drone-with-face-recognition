

import cv2
import face_recognition
import glob

import numpy as np

cam = cv2.VideoCapture(0)

details = [["obama", "Age: 57", "Country: ", "Ethnitity: black", "Bio: President of USA"],
           ["imrankhan",  "Age: 65", "Country: ", "Ethnicity: pashtun", "Bio: President of Pakistan"]]


def train():
    labels = []
    features = []
    images = glob.glob("Images/*.jpg", recursive=False)
    for im in images:
        image = face_recognition.load_image_file(str(im))
        encoding = face_recognition.face_encodings(image)
        if encoding is None or len(encoding) == 0:
            print("Error in image: " + im)
            continue
        features.append(encoding[0])
        im = im.replace("Images\\", "")
        im = ''.join([i for i in im if not i.isdigit()])
        labels.append(im[:im.index(".")])

    return labels, features


def get_desc(label):
    global details
    for d in details:
        if label.lower().startswith(d[0]): return d
    return None


def recognize(face):
    global features
    global labels
    unknown_face_encodings = face_recognition.face_encodings(face)
    if len(unknown_face_encodings) == 0: return 0, None
    results = face_recognition.face_distance(features, unknown_face_encodings[0])
    conf = 1
    min_index = 0
    for i,r in enumerate(results):
        if r < conf: min_index = i ; conf = r
    if len(labels) == 0: return 0, None
    return conf, labels[min_index]


labels, features = train()

while True:

    res, raw_frame = cam.retrieve()
    if raw_frame is None: continue

    cv2.waitKey(1)

    face_locations = face_recognition.face_locations(raw_frame)

    for (t,r,b,l) in face_locations:
        cv2.rectangle(raw_frame, (l,t), (r,b), (0,255,255))

        face = raw_frame[t:b, l:r]
        conf, label = recognize(face)
        if conf == 0: continue
        desc = get_desc(label)
        if desc is not None:
            cv2.putText(raw_frame, desc[1], (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), thickness=1)
            cv2.putText(raw_frame, desc[2], (10, 40), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), thickness=1)
            cv2.putText(raw_frame, desc[3], (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), thickness=1)
            cv2.putText(raw_frame, desc[4], (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), thickness=1)
        cv2.putText(raw_frame, label,(l,t), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), thickness=2)

    cv2.imshow("raw", raw_frame)

#
# my_face_encoding now contains a universal 'encoding' of my facial features that can be compared to any other picture of a face!
#
# # Now we can see the two face encodings are of the same person with `compare_faces`!
#

#
# if results[0] == True:
#     print("It's a picture of obama!")
# else:
#     print("It's not a picture of me!")
